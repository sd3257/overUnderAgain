/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LeftB                motor         20              
// LeftF                motor         12              
// RightB               motor         10              
// RightF               motor         7               
// lswitch              limit         E               
// Cata                 motor         8               
// Blocker              motor         19              
// Wings                digital_out   H               
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include<cmath>
#include<iostream>
using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/
motor_group   leftside( LeftF, LeftB );
motor_group   rightside( RightF, RightB );


int intake;
void press(){
  if(intake == 0){
   intake++; 
  }else if(intake == 1){
    intake = intake - 1;
  }
}

void load(){
  bool pressing = lswitch.pressing();
  if(pressing== false){
    Cata.spin(fwd);
  }else{
    Cata.stop(hold);
  }

}
void shoot(){
  bool pressing = lswitch.pressing();
  if(pressing){
   Cata.spinFor(fwd, 80, degrees);
  }else{
    load();
  }

}




bool resetmotors = false;

bool EndrivePID = true;

float degtoinches(double degrees){
  double x = degrees/70.2;
  return x;

}

bool driveEN;
void drivePID(double desired, double tdesired, bool reset, float x){
  tdesired = tdesired/70.42;
  float kP = 0.8;
  float kI = 0;
  float kD= 0;

  double error;
  double preverror;
  double derevative;
  double totalerror = 0;

  float tkP = 0.6408;
  float tkI = 0.0;
  float tkD = 0.00;

  double terror;
  double tpreverror;
  double tderevative;
  double ttotalerror=0;
  double leftpos = (leftside.position(degrees));
  double rightpos = (rightside.position(degrees));




    double averagepos = ((leftpos + rightpos)/2)/72.4;
    //fwd
    error = averagepos-desired;


    totalerror = totalerror+error;
    derevative = error - preverror;

    //turning
    double taveragepos = leftpos - rightpos;
    terror = tdesired- taveragepos;
    ttotalerror += terror;
    tderevative = terror - tpreverror;
  



  if(reset){
    rightside.resetPosition();
    leftside.resetPosition();

  }
  

  while(fabs(error) >= x || fabs(terror) >= 4){
    load();
    double leftpos = (leftside.position(degrees));
    double rightpos = rightside.position(degrees);

    double averagepos = ((leftpos + rightpos)/2)/72.4;
    
    //fwd

    error = desired-averagepos;


    totalerror = totalerror+error;
    derevative = error - preverror;
    double fmotorpower = (error *kP +derevative *kD + totalerror *kI );



    //turning
    int taveragepos = (leftpos - rightpos)/70.4;
    terror = taveragepos- tdesired;
    ttotalerror += terror;
    tderevative = terror - tpreverror;
    double tmotorpower = (terror *tkP +tderevative *tkD + ttotalerror *tkI );


    //caclutlations
    rightside.spin(forward, fmotorpower + tmotorpower, volt);
    leftside.spin(forward, fmotorpower - tmotorpower, volt);

    //preverror
    tpreverror = terror;
    preverror = error;
    wait(10, msec);
  }
  Controller1.Screen.print("done\n");
}

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*void actuateintake(){
  Intake.setVelocity(10, pct);
  IntakeActu.spinFor(forward, 10, degrees);
}

*/
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  
  /*
  load();
  */
  drivePID(-8, 0, true, 2);
  drivePID(0, 420, true, 2);
  drivePID(-18, 0, true, 2);
  drivePID(15, 0, true, 2);
  drivePID(0,0, true, 2);

  //robot is on the other side now
  //turns for curve
  /*
  drivePID(0, 0, true);
  drivePID(10, 0, true);
  drivePID(0, 1250, true);
 
  drivePID(13, 0, true);
  drivePID(0,0,true);
  //
  //curve
  drivePID(0, -1320, true);
  drivePID(30, -1120, true);
  
  //go fwd
  drivePID(9, 0, true);



  drivePID(0,0,true);

  drivePID(23, 0, true);

  drivePID(-30, -1320,true);
  
  */

  //wait(3, sec);
  //
  //drivePID(1625, 300, true);

 // drivePID(-750, 0, true);
  //drivePID(-500, 0, true);
  //drivePID(500, 0, true);
  //
  //drivePID(-1800, 300, true);
  //drivePID(1000, 0, true);


  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
}
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
double turning = 0.6;
void usercontrol(void) {
  // User control code here, inside the loop
  EndrivePID = false;
  leftside.setVelocity(100, pct);
  rightside.setVelocity(100, pct);
  Cata.setVelocity(100, pct);
  Wings.set(false);
  Blocker.setVelocity(80, pct);

  while (1) {

   //////////////////// //load();
    //Calculations for drivetrain
    double turnval = Controller1.Axis1.position(percent);
    double forwardval = -Controller1.Axis3.position(percent);
    double turnvolt = -turnval * 0.12;
    double forwardvolt = forwardval * 0.12 *(1-(abs(turnvolt/12.0) * turning));

    rightside.spin(forward, forwardvolt-turnvolt, volt);
    leftside.spin(forward, forwardvolt + turnvolt, volt);
//intake
/*
    if(Controller1.ButtonB.pressing()){
      IntakeActu.spin(reverse);
    }else{
      IntakeActu.stop(hold);
    }
*/
    //wings
    if(Controller1.ButtonDown.pressing()){
      Wings.set(true);
    }
    if(Controller1.ButtonUp.pressing()){
      Wings.set(false);
    }

    if(Controller1.ButtonX.pressing()){
      shoot();
    }else{
      load();
      }
  

  
   if(Controller1.ButtonR1.pressing()){
     Blocker.spin(fwd);
   }else if(Controller1.ButtonR2.pressing()){
     Blocker.spin(reverse);

        }else{
          Blocker.stop(hold);
        }
  /* if(intake ==1){
     Intake.spin(fwd);
   }else if(intake == 0){
     Intake.stop(hold);
   }else{
     Intake.stop(hold);
   }
  */
   // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.
    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // ........................................................................
    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
