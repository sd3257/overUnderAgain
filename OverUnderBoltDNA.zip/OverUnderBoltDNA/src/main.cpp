/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// LeftF                motor         19              
// LeftB                motor         6               
// LeftM                motor         10              
// RightF               motor         13              
// RightB               motor         3               
// RightM               motor         1               
// Inertial             inertial      7               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

motor_group leftside(LeftF, LeftB, LeftM);
motor_group rightside(RightF, RightB, RightM);


// A global instance of competition
competition Competition;

bool resetmotors = false;

bool EndrivePID = true;

float degtoinches(double degrees){
  double x = degrees/70.2;
  return x;

}


void drivePID(float errori, float terrori, float desiredinput, float tdesiredinput, bool reset){
  float desired = desiredinput;
  float tdesired = tdesiredinput;

  float kP = 0.8;
  float kI = 0;
  float kD= 0;

  double error = 10;
  double preverror;
  
  double derevative;
  double totalerror = 0;

  float tkP = 0.6408;
  float tkI = 0.0;
  float tkD = 0.00;

  double terror;
  double tpreverror;
  double tderevative;
  double ttotalerror=0;

  /*
  double leftpos = (leftside.position(degrees));
  double rightpos = (rightside.position(degrees));




    double averagepos = ((leftpos + rightpos)/2);
    //fwd
    error = averagepos-desired;


    totalerror = totalerror+error;
    derevative = error - preverror;

    //turning
    double taveragepos = leftpos - rightpos;
    terror = tdesired- taveragepos;
    ttotalerror += terror;
    tderevative = terror - tpreverror;
    */


  if(reset){
    rightside.resetPosition();
    leftside.resetPosition();
    Inertial.resetHeading();

  }
  

  while(fabs(error) >= errori || fabs(terror) >= terrori){

    double leftpos = (leftside.position(degrees));
    double rightpos = rightside.position(degrees);

    double averagepos = (leftpos + rightpos)/2;
    
    //fwd

    error = desired-averagepos;


    totalerror = totalerror+error;
    derevative = error - preverror;
    double fmotorpower = (error *kP +derevative *kD + totalerror *kI )/12;



    //turning
    //int taveragepos = (leftpos - rightpos)/70.4;
    float taveragepos = Inertial.heading();

    terror = taveragepos- tdesired;
    ttotalerror += terror;
    tderevative = terror - tpreverror;
    double tmotorpower = (terror *tkP +tderevative *tkD + ttotalerror *tkI )/12;


    //caclutlations
    rightside.spin(forward, fmotorpower + tmotorpower, volt);
    leftside.spin(forward, fmotorpower - tmotorpower, volt);

    //preverror
    tpreverror = terror;
    preverror = error;
    wait(10, msec);
  }
  printf("endf");
}



void pre_auton(void) {
  Inertial.calibrate();
  

  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  drivePID(5, 1, 10, 0, true);
  drivePID(5, 1, 0, 90, true);


  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.

    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // ........................................................................

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
